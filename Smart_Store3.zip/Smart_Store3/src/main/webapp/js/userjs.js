// متن‌ها به سه زبان (فارسی، انگلیسی و پشتو) تعریف شده‌اند
var texts = {
	'en': {

		//header
		'name_products': 'Name Products',
		'TV': 'TV',
		'machin': 'MACHIN',
		'shop_place': 'location',
		'your_profile': ' your profile',
		'sign': 'sign in',
		'name_products1': 'name products',
		'machin1': 'machin',
		'search': 'search',
		'language': 'language',
		'wishlist': 'wishlist',
		'cart': 'cart',
		'cart1': 'cart',
		'payment': 'payment',
		'home': 'Home',
		'name_products2': ' name_products',
		'admin': 'Admin',


		//index
	
		'wishlist1': 'add to wishlist',
		'view': 'quick view',
		'cart2': 'add to cart',
		'Days': 'Days',
		'Hours': 'Hours',
		'Mins': 'Mins',
		'Secs': 'Secs',
		'week': 'hot deal this week',
		'Collection': 'New Collection Up to 50% OFF',
		'Shop': 'Shop now',
		'machin3': 'machin',
		'wishlist2': 'add to wishlist',
		'view1': 'quick view',
		'cart3': 'add to cart',
		'products1': 'all products',
		'address': 'You can contact us through email or other applications below',
		'Subscribe': 'Subscribe',
		'location': 'location'
	
		




	},
	'fa': {

		//header
		'name_products': 'نام محصولات',
		'TV': 'تلویزیون',
		'machin': 'لباسشویی',
		'shop_place': 'موقعیت دوکان',
		'your_profile': 'پروفایل شما',
		'sign': 'ثبت نام نکردید',
		'name_products1': 'اسم محصولات',
		
		'machin1': 'لباسشویی',
		'search': 'جستوجو',
		'language': 'تعیین زبان',
		'wishlist': 'لیست مورد علاقه شما',
		'cart': 'سبد خرید',
		'cart1': 'دیدن سبد خرید',
		'payment': 'پرداخت',
		'home': 'صفحه اصلی',
		
		'name_products2': 'نمایش محصول',
		'admin': 'ادمین',
			/*index*/
	
		'wishlist1': 'اضافه کردن به لیست مورد علاقه',
		'view': 'دیدن با جریات',
		'cart2': 'اضافه کردن کارت',
		'Days': 'روز',
		'Hours': 'ساعت', 
		'Mins': 'دقیقه',
		'Secs': 'ثانیه',
		'week': 'معامله داغ این هفته',
		'Collection': 'مجموعه جدید تا 50% تخفیف',
		'Shop': 'خزید همین حالا',
		'machin3': 'لباسشویی',
		'wishlist2': 'به لیست علاقه مندی ها اضافه کنید',
		'view1': 'مشاهده سریع',
		'cart3': 'اضافه کردن به سبد خرید',
		'products1': 'تمام محضولات',
		'address': 'میتوانید از طریق ایمیل یا دیگر اپلیکشن های  پایین با ما در ارتباط باشید',
		'Subscribe': 'اشتراک در',
		'location': 'موفعیت'
		
		




	}
};

// تنظیم زبان اولیه به انگلیسی
var currentLanguage = 'fa';

// تابعی برای به‌روزرسانی متن‌ها بر اساس زبان فعلی
function updateTexts() {
	//header
	document.getElementById('name_products').textContent = texts[currentLanguage]['name_products'];
	//document.getElementById('TV').textContent = texts[currentLanguage]['TV'];
	document.getElementById('machin').textContent = texts[currentLanguage]['machin'];
	document.getElementById('name_products').textContent = texts[currentLanguage]['name_products'];
	document.getElementById('your_profile').textContent = texts[currentLanguage]['your_profile'];
	document.getElementById('sign').textContent = texts[currentLanguage]['sign'];
	document.getElementById('name_products1').textContent = texts[currentLanguage]['name_products1'];
	document.getElementById('TV1').textContent = texts[currentLanguage]['TV1'];
	document.getElementById('machin1').textContent = texts[currentLanguage]['machin1'];
	document.getElementById('search').textContent = texts[currentLanguage]['search'];
	document.getElementById('language').textContent = texts[currentLanguage]['language'];
	
	
	document.getElementById('wishlist').textContent = texts[currentLanguage]['wishlist'];
	document.getElementById('TV').firstChild.textContent = texts[currentLanguage]['TV'];
	
	
	//document.getElementById('wishlist').textContent = texts[currentLanguage]['wishlist'];
	document.getElementById('cart').textContent = texts[currentLanguage]['cart'];
	document.getElementById('cart1').textContent = texts[currentLanguage]['cart1'];
	document.getElementById('payment').textContent = texts[currentLanguage]['payment'];
	document.getElementById('home').textContent = texts[currentLanguage]['home'];
	document.getElementById('shop_place').textContent = texts[currentLanguage]['shop_place'];
	document.getElementById('TV2').textContent = texts[currentLanguage]['TV2'];
	document.getElementById('name_products2').textContent = texts[currentLanguage]['name_products2'];
	document.getElementById('admin').textContent = texts[currentLanguage]['admin'];











}

// تابعی برای تغییر زبان
function changeLanguage(language) {
	currentLanguage = language;
	updateTexts();
}

// رویداد کلیک برای دکمه‌ها
document.getElementById('btnEnglish').addEventListener('click', function() {
	changeLanguage('en');
});

document.getElementById('btnPersian').addEventListener('click', function() {
	changeLanguage('fa');
});


// به‌روزرسانی متن‌ها در بارگیری اولیه صفحه
updateTexts();




function showMessage(message) {
	var modal = document.getElementById("myModal");
	var messageElement = document.getElementById("message");
	messageElement.textContent = message;
	modal.style.display = "block";
	document.body.classList.add("modal-open");
}

function closeModal() {
	var modal = document.getElementById("myModal");
	modal.style.display = "none";
	document.body.classList.remove("modal-open");
}