
    function changeLanguage(language) {
        // ارسال درخواست به سرور برای تغییر زبان
        // در اینجا می‌توانید از AJAX یا fetch برای ارسال درخواست به سرور استفاده کنید
        // و مقادیر منابع زبان را از سرور بارگیری کنید
        // در این مثال، فقط زبان فارسی و انگلیسی را بررسی می‌کنیم
        if (language === 'fa') {
            // بارگیری منابع فارسی
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'resources/messages_fa.properties', true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var messages = parseProperties(xhr.responseText);
                    changeTexts(messages);
                }
            };
            xhr.send();
        } else if (language === 'en') {
            // بارگیری منابع انگلیسی
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'resources/messages.properties', true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var messages = parseProperties(xhr.responseText);
                    changeTexts(messages);
                }
            };
            xhr.send();
        }
    }
    
    function parseProperties(text) {
        var messages = {};
        var lines = text.trim().split('\n');
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (line !== '' && !line.startsWith('#')) {
                var index = line.indexOf('=');
                if (index !== -1) {
                    var key = line.substring(0, index).trim();
                    var value = line.substring(index + 1).trim();
                    messages[key] = value;
                }
            }
        }
        return messages;
    }
    
    function changeTexts(messages) {
        var elements = document.querySelectorAll('[data-i18n]');
        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            var key = element.getAttribute('data-i18n');
            var text = messages[key];
            if (text) {
                element.textContent = text;
            }
        }
    }
