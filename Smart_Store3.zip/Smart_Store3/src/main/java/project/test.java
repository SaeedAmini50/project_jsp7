package project;

import java.util.ListResourceBundle;
public class test extends ListResourceBundle {
   public Object[][] getContents() {
      return contents;
   }
   static final Object[][] contents = {
      {"count.one", "One"},
      {"count.two", "Two"},
      {"count.three", "Three"},
   };
}